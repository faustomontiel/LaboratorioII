﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Automovil : Vehiculo
    {
        private ConsoleColor _color;
        private int _valorHora;


        public Automovil(string patente, ConsoleColor color)
            : base(patente)
        {
            this._color = color;
        }
        public Automovil(string patente, ConsoleColor color, int valorHora)
            : this(patente, color)
        {
            this._valorHora = 50;
        }

        public override string ConsultarDatos()
        {
            return this.ImprimirTicket();
        }

        public override string ImprimirTicket()
        {
            StringBuilder sb = new StringBuilder();
            int costo;

            sb.Append(base.ImprimirTicket());
            sb.AppendFormat("Color:{0}", this._color);

            costo = (int)(this._ingreso - DateTime.Now).TotalHours * this._valorHora;
            sb.AppendFormat("Costo Estadia: {0}",costo.ToString());

            return sb.ToString();
        }
        public override bool Equals(object obj)
        {
            bool retorno = false;

            if (this == obj)
            {
                retorno = true;
            }
            return retorno;
        }


    }
}
