﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class PickUp : Vehiculo
    {
        private string _modelo;
        private int _valorHora;

        public PickUp(string patente, string modelo)
            : base(patente)
        {
            this._modelo = modelo;
        }
        public PickUp(string patente, string modelo, int valorHora)
            : this(patente, modelo)
        {
            _valorHora = 70;
        }
        public override string ConsultarDatos()
        {
            return this.ImprimirTicket();
        }

        public override string ImprimirTicket()
        {
            StringBuilder sb = new StringBuilder();
            int costo ;

            sb.Append(base.ImprimirTicket());
            sb.AppendLine("Modelo: "+this._modelo);

            costo = (int)(this._ingreso - DateTime.Now).TotalHours * this._valorHora;
            sb.AppendFormat("Costo Estadia: {0}", costo.ToString());


            return sb.ToString();
        }

        public override bool Equals(object obj)
        {
            bool retorno = false;

            if (this == obj)
            {
                retorno = true;
            }
            return retorno;
        }




    }
}
